#include "framework.h"
#include "FlashingTest.h"


HWND flashTarget;

void OnButtonClick() {
	MessageBox(nullptr, L"Button Clicked!", L"Info", MB_OK);
}

void FlashTaskbarIcon(const int count, HWND hwdn) {
	FLASHWINFO fwi{ sizeof(fwi) };
	fwi.hwnd = flashTarget;
	fwi.uCount = count;
	fwi.dwFlags = FLASHW_TRAY;
	const bool flash_window_result = ::FlashWindowEx(&fwi);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	switch (msg) {
	case WM_COMMAND:
		if (LOWORD(wParam) == 1001) {
			FlashTaskbarIcon(2, hwnd);
		}
		break;
	default:
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}
	return 0;
}

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow) {
	// Register the window class
	WNDCLASS wc = { 0 };
	wc.lpfnWndProc = WndProc;
	wc.hInstance = GetModuleHandle(nullptr);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszClassName = L"MyWindowClass";

	if (!RegisterClass(&wc)) {
		MessageBox(nullptr, L"Window Registration Failed!", L"Error", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	HWND hwnd1 = CreateWindowEx(0, L"MyWindowClass", L"Window 1", WS_OVERLAPPEDWINDOW, 100, 100, 400, 300,
		nullptr, nullptr, GetModuleHandle(nullptr), nullptr);

	if (hwnd1 == nullptr) {
		MessageBox(nullptr, L"Window Creation Failed!", L"Error", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	HWND btn = CreateWindow(
		L"BUTTON",        // Predefined class;
		L"Click me",      // Button text
		WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles
		10,               // x position
		10,               // y position
		100,              // Button width
		30,               // Button height
		hwnd1,            // Parent window
		(HMENU)1001,      // Button identifier (used in WM_COMMAND)
		GetModuleHandle(nullptr),
		nullptr);    

	if (btn == nullptr) {
		MessageBox(nullptr, L"Button Creation Failed!", L"Error", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	// Create the second window
	HWND hwnd2 = CreateWindowEx(0, L"MyWindowClass", L"Window 2", WS_OVERLAPPEDWINDOW, 500, 100, 400, 300,
		nullptr, nullptr, GetModuleHandle(nullptr), nullptr);

	if (hwnd2 == nullptr) {
		MessageBox(nullptr, L"Window Creation Failed!", L"Error", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	// Create the third window
	HWND hwnd3 = CreateWindowEx(0, L"MyWindowClass", L"Window 3", WS_OVERLAPPEDWINDOW, 900, 100, 400, 300,
		nullptr, nullptr, GetModuleHandle(nullptr), nullptr);

	if (hwnd3 == nullptr) {
		MessageBox(nullptr, L"Window Creation Failed!", L"Error", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	flashTarget = hwnd2;

	// Show and update the windows
	ShowWindow(hwnd1, SW_SHOW);
	ShowWindow(hwnd2, SW_SHOW);
	ShowWindow(hwnd3, SW_SHOW);

	MSG msg;
	while (GetMessage(&msg, nullptr, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return msg.wParam;
}